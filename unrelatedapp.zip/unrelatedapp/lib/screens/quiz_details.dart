import 'package:flutter/material.dart';
import 'package:unrelatedapp/models/quiz.dart';

class QuizDetails extends StatefulWidget {
  final Quiz? quiz;
  const QuizDetails({Key? key, this.quiz}) : super(key: key);

  @override
  _QuizDetailsState createState() => _QuizDetailsState();
}

class _QuizDetailsState extends State<QuizDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            color: Color(0xB8BFE4FF),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                  Text(this.widget.quiz!.name),
                  SizedBox(height: 20,),
                  Text(this.widget.quiz!.description,),
                  SizedBox(height: 20,),
                  Text(this.widget.quiz!.questions.toString(),
                  style: TextStyle(
                    fontWeight: FontWeight.bold
                  ),),

              ],
            ),
          )
        ]
      ),
    );
  }
}
