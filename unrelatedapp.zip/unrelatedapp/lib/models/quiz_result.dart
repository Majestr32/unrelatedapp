
class QuizResult{
  String name;
  String imgUrl;
  String result;
  String date;

  QuizResult(this.name, this.imgUrl, this.result, this.date);
}